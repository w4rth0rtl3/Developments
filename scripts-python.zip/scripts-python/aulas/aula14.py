# Aula do laço while

# cont = 5
# apple = False
#
# while not apple:
#     cont = cont - 1
#     print(cont)
#
#     if cont == 1:
#         print('Maça')
#         apple = True
#
# print(' Pega')

#
# while não apple:
#     passo
#
# pega
'''
for i in range(1, 10):
    print(i)
print('Fim')
'''

cont = 1

while cont < 10:
    print(cont)
    cont += 1
print('Fim')

numero = 1

while numero != 0:
    numero = int(input("Digite um numero: "))
    if numero == 7:
        print('EasterEgg')

print('O numero finalmente foi 0')
