'''
frase = 'Curso Em video Python'
print(frase[15:])
print(len(frase))
print(frase.count('o',0,13))
print(frase.count('o',0,13))
print(frase.find('deo'))
print(frase.replace('Python', 'De Hacking'))

print(frase)
print(frase.capitalize())
print(frase.split())
print(frase)
print('-'.join(frase))
'''

frase = "Curso em Video Python"
# print(frase[::2])

# print(frase.upper().count('O'))
print(len(frase.replace('Python', 'Android')))
print(frase.replace('Python', 'Android'))

print(frase[0])
# frase = frase.replace('C', 'J')
# print(frase)

print('Curso' in frase)
print(frase.find('Video'))
dividido = frase.split()
print(dividido[0:2])
print(dividido[2][3])




"""
print('oi')
print('''Um texto muito longo
E
escrito em varias linhas 
tipo essa
e essa aqui tabem''')
"""