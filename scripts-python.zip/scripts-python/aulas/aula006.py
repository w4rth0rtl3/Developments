n1 = input('Digite o valor ')
print(n1.isalpha())