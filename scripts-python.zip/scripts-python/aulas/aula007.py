# nome = str(input('Qual é seu nome ?\n'))
# print('Prazem em te conhecer {:=^20} !'.format(nome))
#

n1 = int(input('Digite um numero: '))
n2 = int(input('Digite outro numero: '))

print('A soma vale {}'.format(n1 + n2))