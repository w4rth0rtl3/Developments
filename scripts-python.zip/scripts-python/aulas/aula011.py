#Como trabalhar com cores no terminal

print("\033[4;30;49mOlá Mundo\033[m !")
