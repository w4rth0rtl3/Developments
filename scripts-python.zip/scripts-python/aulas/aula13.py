# Agora é hora de aprender a repitir as coisas

'''
for c in range(1,10):
    anda
pega

'''

for c in range(1, 10):
    print('Oii {}x vez'.format(c))

print('Tchau')

# O laço com range() sempre para no penultimo ele leva o ultimo como limite, ou seja se for range(0, 90)
# ele vai de 0 a 89 pois o 90 é o seu limite

from time import sleep
print('Contagem regresiva !')
for c in range(10, 0, -1):
    print(c)
    sleep(1)
print('Kabooom')