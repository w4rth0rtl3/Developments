# Condições Aninhadas

# Condições aninhadas são estruturas condicionais dentro de outras estruturas condicionais

nome = str(input('Qual é seu nome: ')).title()
if nome == 'Alisson':
    print('Bem vindo mestre')
elif nome == 'Batata':
    print('Access denied !')
    exit()
else:
    print('Não te conheço mas ...')
print('Tenha um bom dia {}'.format(nome))