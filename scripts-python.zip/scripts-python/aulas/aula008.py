from math import sqrt, floor
num = int(input('Digite um numero: '))
# raiz = math.sqrt(num) #função da biblioteca math que calcula a raiz quadrada
raiz = sqrt(num)
 
#print('A raiz de {} é igual a {:.2f}'.format(num, math.ceil(raiz))) #função ceil arredonda para cima os numeros
print('A raiz de {} é igual a {:.2f}'.format(num, raiz))
print('A raiz de {} é igual a {:.2f}'.format(num, floor(raiz)))#funçaão da bilio. que arredonda para baixo


'''
import math
num = int(input(''))
print(math.sqrt(num))
'''