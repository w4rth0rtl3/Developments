# Aula de condições

#Estruturas condicionais separam o codigo e permite a execução de outros comandos

'''
batata = True

if batata:
    print('Batatatatata é bom')

else:
    print('Batata é bom sim, ta doido !')
'''

# tempo = int(input('Quantos anos tem seu carro ?\n'))
#
# #Forma padrão
# '''
# if tempo <=3:
#     print('Carro novo')
#
# else:
#     print('Carro velho hein')
# '''
# #Forma simplificada
# print('Carro novo' if tempo <=3 else 'Carro velho')
#
# print('\n---FIM---\n')

nome = str(input('Digite seu nome: ')).title().strip()

if  'Alisson' in nome:
    print('{}, seu gostoso'.format(nome))

else:
    print('Tu é feio')

print('oii, {}'.format(nome))