'''
O mesmo professor do exercicio 019.py quer sortear a orem de apresetação de trabalho dos alunos
faça um programa que leia o nome dos quatro alunos e mostre a ordem sorteada
'''

from random import shuffle

a1 = str(input('Digite o nome do aluno: '))
a2 = str(input('Digite o nome do aluno: '))
a3 = str(input('Digite o nome do aluno: '))
a4 = str(input('Digite o nome do aluno: '))

alunos = [a1, a2, a3, a4]
shuffle(alunos)
#
# print('A ordem de apresentação sera \n{}'.format(alunos))

print( 30 * '-','\nA ordem de apresentação será: \n1° {} \n2° {} \n3° {} \n4° {}\n'.format(alunos[0], alunos[1], alunos[2], alunos[3]) + 30 * '-')
