'''
Desenvolva um programa que leia o comprimento de três retas
e diga ao usuário se elas podem ou não formar um triângulo
'''

reta1 = float(input('1° Digite o valor de uma reta: '))
reta2 = float(input('2° Digite o valor de uma reta: '))
reta3 = float(input('3° Digite o valor de uma reta: '))

# fiquei com preguiça de pesquisar a regra kkk

if reta1 < reta2 + reta3 and reta2 < reta1 + reta3 and reta3 < reta1 + reta2:
    print('Pode formar um triangulo')
else:
    print('Não pode formar um triangulo')

