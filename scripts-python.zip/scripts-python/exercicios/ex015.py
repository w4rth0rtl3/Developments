'''
Escreva um programa que pergunte a quantidade de KM pecorridos por um carro alugado e a quantidade de
dias pelo quais ele foi alugado. Calcule o preço a pagar sabendo que o carro custa R$60 por dia e
R$0,15 por km rodado.
'''

dias = int(input('Digite quantos dias você alugou com o carro: '))
kms = float(input('Digite quantos Km você rodou com o carro: '))
total = (dias * 60) + (kms * 0.15)
print('-' * 30)
print('Total a pagar R${:.2f}'.format(total))
print('-' * 30)