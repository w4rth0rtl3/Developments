'''
Crie um programa que leia vários números inteiros pelo teclado. O programa só vai parar quando o usuário digitar o valor
999, que é a condição de parada. No final, mostre quantos números foram digitados e qual foi a soma entre eles
(desconsiderando o flag)
'''

n = 0
print('Digite numeros inteiros\ndigite 999 para sair')
cont = 0
tot = 0
while n != 999:
    n = int(input('Digite o numero: '))
    cont += 1
    tot += n

print('Total de numeros {}\nSoma dos numeros {}'.format(cont - 1, tot - 999))
tot = tot - 999
cont = cont - 1
print('Total de numeros {}\nSoma dos numeros {}'.format(cont, tot))