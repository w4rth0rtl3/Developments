'''
Desenvolva um programa que leia as duas notas de um aluno, calcule a e mostre a sua media
'''

nota1 = float(input('Digite a 1ª nota: '))
nota2 = float(input('Digite a 2ª nota: '))
media = (nota1 + nota2) / 2

print('A media do aluno é: {:.1f}'.format(media))
print('A media do aluno é: {:.1f}'.format((nota1 + nota2) / 2))