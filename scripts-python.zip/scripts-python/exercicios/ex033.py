'''
Faça um programa que leia três números e mostre qual é o maior e qual é o menor
'''

numero1 = int(input('Digite o 1° numero ')) # 1
numero2 = int(input('Digite o 2° numero ')) # 2
numero3 = int(input('Digite o 3° numero ')) # 3
max = numero1

if numero1 > numero2 and numero1 > numero3:
    print(numero1)

elif numero2 > numero1 and numero2 > numero3:
    print(numero2)

elif numero3 > numero1 and numero3 > numero2:
    print(numero3)

else:
    print('Deu ruim')

'''
Esqueci de mostrar o menor kkkkk
'''