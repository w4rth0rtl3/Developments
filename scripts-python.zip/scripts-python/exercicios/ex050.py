'''
Desenvolva um programa que leia seis números inteiros e mostre a soma apenas daqueles números pares,
desconsidere os numeros impares
'''

s = 0
for i in range(1, 6 + 1):
    n = int(input('Digite o {}° número: '.format(i)))

    if n % 2 == 0:
        s += n

print('\nA soma de todos os números pares é', s)

