'''
Crie um programa que lia o nome de uma cidade e diga se ela começa ou não com o nome "Santo"
'''

cidade = str(input('Digite o nome de uma cidade: ')).title().strip()
# print('Santo' in cidade)
print('A cidade começa com Santo ?\n{}'.format('Santo' in cidade.split()[0]))