'''
Faça um programa que leia algo pelo teclado e mostre na tela seu tipo primitivo
e informações sobre ele
'''

pergunta = input('Digite alguma coisa: ')
print(type(pergunta))
print('O que voce digitou é numerico: ', pergunta.isnumeric())
print('O que voce digitou é alfabetico: ', pergunta.isalpha())


'''Como eu tenho um conhecimento a mais do que o necessario para o desafio irei dificultar
fazendo o programa mostrar apenas o que for verdade'''

if pergunta.isnumeric() == True:
    print('{} é numerico'.format(pergunta))
elif pergunta.isalpha() == True:
    print('{} é alfabetico'.format(pergunta))
elif pergunta.isalnum() == True:
    print('{} é alfa numerico'.format(pergunta))
else:
    print('Algo deu errado, provavelmente você digitou um caractere invalido')
