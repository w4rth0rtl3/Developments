'''
Crie um programa que mostre na tela todos os números pares que estão entre o intervalo entre 1 e 50
'''

print('Números pares de 0 a 50 !\n')

for numero in range(1, 50 + 1):
    print('.')
    if numero % 2 == 0:
        print('{}'.format(numero), end=' ')
        #print(n, end=' ')

'''
Guanabara demostrou de um jeito que consumiria menos "memoria" do processador 
'''
print('\n')
for n in range(2, 51, 2):
    print(n, end=' ')
