'''
Crie um programa que leia um numero e diga se ele é par ou impar
'''

num = int(input("Digite um nuemero: "))

if num % 2 == 0:
    print('O numero "{}" é Par'.format(num))
else:
    print('O numero "{}" é Impar'.format(num))