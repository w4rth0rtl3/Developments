'''
Desenvolva um programa que leia quantoss reais uma pessoa tenha e calcule qunantos dolares ela pode comprar
cosendere 1.00dolares como 3.27 reais
'''

reais = float(input('Digite sua quantia de dinheiro em reais: R$ '))
dolares = reais / 3.27
print('com R${:.2f} você pode comprar {:.2f} dolares'.format(reais ,dolares))

'''
Talvez fosse mais bonito criar uma variavel chamada dolar que armazenaria apenas o valor do dolar,
e criar outra que executasse a conversão

reais = float(input("XXXXXX"))
dolar = 3.27
conversor = reias / dolar
print(conversor)
'''