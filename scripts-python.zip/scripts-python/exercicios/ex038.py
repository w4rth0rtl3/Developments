'''
Escreva um programa que leia dois números inteiros e compare-os, mostrando uma mensagem:
- O primeiro valor é maior
- O segundo valor é maior
- Não existe valor maior, os dois são iguais
'''

num1 = int(input('Digite um numero: '))
num2 = int(input('Digite um outro numeor: '))

if num1 > num2:
    print('O numero {} é o maior'.format(num1))
elif num2 > num1:
    print('O numero {} é o maior'.format(num2))
else:
    print('Eles são iguais')
