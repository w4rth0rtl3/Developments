'''
Desenvolva um programa que leia um valor em metros e o exiba em centimetros e milimetros
'''

metros = float(input('Digite um valor em metros: '))
centimetros = metros * 100
milimetros = metros * 1000
print('Centimetros: {:.2f}cm'.format(centimetros))
print('Milimetros: {:.2f}mm'.format(milimetros))