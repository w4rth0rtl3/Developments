'''
Escreve um algoritimo que transforme de Graus celsius para fahrenheit
'''

celsius = float(input('Digite os graus em °C: '))
fahrenheit = celsius * 1.8 + 32
print('{}°C é {}°F'.format(celsius, fahrenheit))