'''
Um professor quer sortear um dos seus quatros alunos apagar o quaddro. Faça um programa que ajude ele
lendo o nome deles e escrevendo o nome do escolhido.
'''

#import random
from random import shuffle, choice

a1 = str(input('Digite o nome do aluno: '))
a2 = str(input('Digite o nome do aluno: '))
a3 = str(input('Digite o nome do aluno: '))
a4 = str(input('Digite o nome do aluno: '))

alunos = [a1, a2, a3, a4]
# print(alunos)
lista  = shuffle(alunos)
# print(alunos)
escolha = choice(alunos)

print('O aluno escolhido foi {}'.format(escolha))