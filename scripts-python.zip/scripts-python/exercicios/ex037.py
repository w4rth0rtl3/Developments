'''
Escreva um programa que leia um numero inteiro qualquer e peça para o usuário escolher qual será
a base de conversão

1 - para binário
2 - para octal
3 - hexadecimal
'''

print(20 * '-','Conversor de numeros', 20 * '-')
numero = int(input('Digite um numero: '))
base = int(input('''
Digite um número para escolher a base de conversão
    1 - para binário
    2 - para octal
    3 - hexadecimal

> '''))

#print(base)

if base == 1:
    print('{}'.format(bin(numero)[2:]))
    #print('{}'.format(bin(numero)))

elif base == 2:
    print('{}'.format(oct(numero)[2:]))
    #print('{}'.format(oct(numero)))

elif base == 3:
    print('{}'.format(hex(numero))[2:])
    #print('{}'.format(hex(numero)))


else:
    print('Não entendi, digite apenas os numeros 1, 2 ou 3 para realizar a escolha da base\n ou então um numero inteiro no inicio')
    exit()

'''
Tive problemas na questão de formatar o resultado
'''