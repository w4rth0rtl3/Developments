'''
Escreva um programa que leia a velocidade de um carro. Se ele ultrapassar 80 km/h, mostre uma
mensagem dizendo que ele foi multado. A multa vai custar R$ 7,00 por cada km acima do limite.
'''

velocidade = float(input('Digite a velocidade Km/h '))

if velocidade > 80:
    print('Multado')
    print('Você terá que pagar {:.2f} R$ '.format((velocidade - 80) * 7))
else:
    print('Tranquilo, diriga com segurança')