'''
Crie um programa que leia o ano de nascimento de sete pessoas.
No final mostre quantas pessoas ainda não atingiram a maioridade e quantas já são
maiores.
'''

from datetime import date

maiores = 0
menores = 0
for i in range(1, 6 + 1):
    nasc = int(input('Digite o ano de nascimento dá {}° pessoa: '.format(i)))


    if date.today().year - nasc >= 18:
        #print('Maior de idade')
        maiores += 1

    else:
        #print('menor')
        menores += 1

print('há {} maiores de idade e {} menores'.format(maiores, menores))