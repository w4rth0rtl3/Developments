'''
Faça um program que leia um numero de 0 a 9999 e mostre na tela ca um dos digitos separados
ex:
numero : 1834

unidade: 4
dezena: 3
centana: 8
milhar: 1
'''

# numero = input('Digite um numero entre 0 e 9999')
# print('O numero é {}'.format(numero))
# print('Unidade: {}'.format(numero[]))

num = int(input('Informe um número: '))
n = str(num)
u = num // 1 % 10
d = num // 10 % 10
c = num // 100 % 10
m = num // 1000 % 10
print('Analisando o numero {}'.format(num))
#print('Unidade {}\nDezena {}\nCentena {}\nMilhar {}'.format(n[3],n[2],n[1],n[0]))
print('Unidade {}\nDezena {}\nCentena {}\nMilhar {}'.format(u, d, c, m))



'''
Vou voltar nesse dps
'''