'''

Desenvolva um programa que leia o nome, idade e sexo de 4 pessoas. No final do programa
mostre:

A media de idade do grupo
Qual é o nome do homem mais velho
Quantas mulheres tem menos de 20 anos

'''

medidade = 0
idade_velho = 0
nome_velho = ''
meninas = 0

for p in range(1, 4 + 1):
    print('----{}----'.format(p))
    nome = str(input('Nome: '))
    idade = int(input('Idade: '))
    sexo = str(input('Sexo M/F: ')).upper()
    print(10 * '-')

    if p == 1:
        maisvelho = idade

    if sexo == 'M' and idade > idade_velho:
        nome_velho = nome
        idade_velho = idade

    if sexo == 'F' and idade < 20:
        meninas += 1

    medidade +=idade

print('A media da idade de todo mundo é {:.2f}'.format(medidade / 4))
print('O homem mais velho é {} e tem {} anos'.format(nome_velho, idade_velho))

if meninas > 1:
    print('A quantia de mulheres com menos de 20 anos é {} meninas'.format(meninas))

elif meninas == 1:
    print('A apenas 1 menina com menos de 20 anos')

else:
    print('Não há mulheres com menos de 20 anos')