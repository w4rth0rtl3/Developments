'''
Refaça o exercicio 009 mostrando a tabuada de um número que o usuário escolher  so que utilizando o laço for
'''

print("-=" * 10 + 'Tabuada' + '=-' * 10)

num = int(input('Digite um número: '))

print("> tabuade do {}".format(num))

for i in range(1, 10 + 1):
    print("{} x {} = {}".format(num, i, num * i))