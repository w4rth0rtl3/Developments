'''
Crie um programa que leia uma frase qualquer e diga se ela é um palidromom descconsederandos os espaços
'''

frase = str(input('Digite uma frase: ')).strip().upper().replace(' ', '')  # Pega a frase
ocontrario = str('')

# Esse foi o jeito que eu fiz de começo MUITO MAIS FACIL
if frase == frase[::-1]:
    print('Palindromo 1')
    print(frase[::-1])

else:
    print('Não é palindromo')
    print(frase[::-1])
# O jeito abaixo é utilizando for
ocontrario = str('')
for i in frase[::-1]:
    ocontrario += i

if ocontrario == frase:
    print('É palindromo')

else:
    print('Não é palindromo')


'''
Rever a aula de tratamento de strings
'''