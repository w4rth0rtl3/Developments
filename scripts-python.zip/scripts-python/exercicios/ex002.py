'''
Faça um programa qye leia o ome de uma pessoa e mostre uma mensagem de boas vindas
https://www.youtube.com/watch?v=FNqdV5Zb_5Q
'''

nome = input('Digite seu nome: ') # a varivel nome recebe um input/entrada de dados do usuário
# Não foi necessario a utilização da função str() para conventer o input em string, pois a mesma tem esse formato como padrão
print('Seja bem vindo', nome) # mostra na tela uma mensagem e o nome digitado
print('Seja bem vindo {}'.format(nome)) # essas e a proxima linha fazem a mesma coisa porém de forma diferente
print(f"Seja bem vindo {nome}")
