'''
Faça um programa que leia o nome completo de uma pessoa,
mostrando em seguida o primeiro e o último nome separadamente.
'''

nome_completo = str(input('Digite seu nome completo: ')).strip()
nome = nome_completo.split()
#print(nome)
print('Analisando o seu nome... ')
print('Primeiro nome: {}'.format(nome[0]))
print('Ultimo nome: {}'.format(nome[-1]))

