'''
Faça um programa em python que abra e reproduza o audio de um arquivo MP3
'''

import pygame

pygame.init()
pygame.mixer.init()
pygame.mixer.music.load('msg.mp3')
pygame.mixer.music.play()

while pygame.mixer.music.get_busy():
    pass

'''
Apanhei demais nesse desafio
PS: apanhei muito mesmo kkkkkkkkkkkkk
'''