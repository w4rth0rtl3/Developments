'''
Crie um programa que leia vários números inteiros pelo teclado. No final da execução, mostre a média entre todos os
valores e qual foi o maior e o menor valores lidos. O programa deve perguntar ao usuário se ele quer ou não continuar a
digitar valores.
'''

asking = "S".upper()

cont = 0
tot = 0
menor = 0
maior = 0

while asking == 'S'.upper():
    num = int(input('Digite um  numero: '))
    cont += 1
    tot += num

    if cont == 1:
        menor = num
        maior = num

    else:
        if num > maior:
            maior = num

        elif num < menor:
            menor = num

    asking = str(input('Quer continuar S/N: ')).upper().strip()
media = tot / num

print('Você digitou ao todo {} e a media foi {}'.format(cont, media))
print('Maior valor digitado  {} e menor valor digitado {}'.format(maior, menor))

'''
resp = str(input('Quer continuar S/N'))

while resp in 'Ss'
'''