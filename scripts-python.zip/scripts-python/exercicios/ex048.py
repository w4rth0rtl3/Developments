'''
Faça um programa que calcule a soma entre todos os números impares que são multiplos de 3 e que se
encontram entre o intervalo de 1 até 500
'''

s = 0
cont = 0
for i in range (1, 500 + 1):
    if i % 3 == 0:
        if i % 2 != 0:
            s += i
            cont += 1

print('A soma de todos os {} números impares de 0 a 500 e multiplos de 3 é\n\n-> {}'.format(cont, s))

'''
Novamente uma forma que gasta menos memória do processador 
'''

soma = 0
cont = 0
for n in range(1, 500 + 1, 2):
    if n % 3 == 0:
        soma += n
        cont += 1
print('A soma dos {} números impares e multiplos de 3 entre 1 e 500 é \n-> {}'.format(cont, soma))

'''
Essa segunda forma utiliza do laço for para automaticamente ir apenas nos números impares
ao invés de utilizar um if 
'''