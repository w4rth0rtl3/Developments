'''
Desenvolva um programa que leia o primeiro termo e a razão de uma PA. No final mostre os 10
primeiros termos dessa progressão
'''

primeiro_termo = int(input('Digite o primeiro termo da PA: '))
razao = int(input('Digite a Razão da PA: '))


decimo = primeiro_termo + (10 - 1) * razao
for c in range(primeiro_termo, decimo + razao, razao):
    print(c, end=' ')

print('Acabou')

'''
Travei com a questão de matematica e acabei fazendo junto do video 
'''