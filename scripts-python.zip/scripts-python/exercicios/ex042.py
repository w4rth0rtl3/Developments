'''
Refaça o desafio 035 dos triamgulos acresentado o recurso de mostrar se
o triangulo é equilatero, issoceles ou escaleno
'''

reta1 = float(input('Digite o numero de uma reta: '))
reta2 = float(input('Digite o numero de uma reta: '))
reta3 = float(input('Digite o numero de uma reta: '))

if reta1 < reta2 + reta3 and reta2 < reta1 + reta3 and reta3 < reta1 + reta2:
    print('Pode ser um triangulo')
    if reta1 == reta2 and reta1 == reta3:
        print('Tem um triangulo: equilátero')

    elif reta1 == reta2 or reta1 == reta3 and reta2 != reta3 or reta1 != reta2:
        print('Tem um triangulo: isosceles')

    else:
        print('Tem um triangulo: escaleno')

else:
    print('Não pode ser um triangulo')