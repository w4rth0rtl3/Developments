'''
Faça um programa que leia um numro inteiro e mostra na sua teal seu sucessor e antecessor
'''

numero = int(input('Digite um numero: '))
print('O sucessor do numero {} é {}\nO antecessor do numero {} é {}'.format(numero, (numero + 1), numero, (numero - 1)))

