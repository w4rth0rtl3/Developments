'''
Crie um programa que leia o nome de uma pessoa e diga se ela tem "Silva" no nome
'''

nome = str(input('Digite seu nome completo: ')).title()
print('Tem silva no nome ?\n{}'.format('Silva' in nome))