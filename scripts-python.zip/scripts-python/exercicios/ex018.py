'''
Faça um programa que leia um ângulo qualquer e mostre na tela o valor do seno, cosseno e tangente
desse angulo digiteado pelo usuário
'''

import math

angulo = float(input('Digite um angulo: '))
seno = math.sin(math.radians(angulo))
cosn = math.cos(math.radians(angulo))
tang = math.tan(math.radians(angulo))

print('O Angulo é {:.2f}\nO seno é {:.2f}\nO coseno é {:.2f}\nA tangente é {:.2f}\n'.format(angulo, seno, cosn, tang))


