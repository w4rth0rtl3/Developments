'''
Faça um algoritmo que leia o preço de um produto e mostre
seu novo preço com 5% de desconto
'''

preco = float(input('Digite o preço do produto: '))
desconto = (preco * 5) / 100
preco = preco - desconto

print('O preço do produto com 5% de desconto é: {:.2f} R$'.format(preco))

'''
É possivel fazer um algoritmo melhor utilizando apenas duas variaveis
preco = float(input))
novo = preco - (preco * 5) / 100
print(novo)
'''

20 - (20 * 5 / 100)