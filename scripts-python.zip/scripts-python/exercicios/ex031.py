'''
Desenvolva um programa que pergunte a distância de uma viagem em km. Calcule o preço da passagem,
cobrando R$ 0,50 por km para viagens de até 200 km e R$ 0,45 para viagens mais longas.
'''

distancia = int(input('Qual a distancia da viagem: Km '))

if distancia <= 200:
    print('Preço é {:.2f} R$'.format(distancia * 0.50))
else:
    print('Preço é {:.2f} R$'.format(distancia * 0.45))