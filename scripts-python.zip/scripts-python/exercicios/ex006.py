'''
Crie um alogirtmo que leia um numero e mostre o dobro, triplo e a raiz quadrada dele
'''

numero = int(input('Digite um numero: '))
print('O numero é {}\nO Dobro dele é {}\nO triplo dele é {}\nA raiz quadrada dele é {:.2f}'.format(numero, (numero * 2), (numero * 3), (numero ** (1/2))))