'''
Crie um programa que leia o nome completo de uma pessoa e mostre:
o nome com todas as letras maiusculas
o nome com todas as letras minusculas
quantas letras no total (sem considerar espaço)
quantas letras tem o primeiro nome
'''

nome = str(input('Digite seu nome: ')).strip()

print('Em maiusculo {}'.format(nome.upper()))
print('Em minusculo {}'.format(nome.lower()))
sem_espaco = nome.replace(' ', '')
# print(sem_espaco)
print('Total de letras no nome {}'.format(len(sem_espaco)))
print('Seu primeiro nome tem ao todo {} letras'.format(len(nome.split()[0])))

'''
print('Total de letras no nome {}'.format(len(nome) - nome.count(' ')))
print('Seu primeiro nome tem ao todo {} letras'.format(nome.find(' ')))
'''