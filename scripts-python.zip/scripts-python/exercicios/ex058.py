'''
Melhore o jogo do desafio 028 onde o computador vai 'pensar' em um numero (0 - 10) e o usuário ira
adivinhar, so que agora o jogador vai tentar advinhar até acertar, mostrando no final quantos palpites
foram necessarios para vencer
'''

from random import randint

numero = randint(0, 10)

print(numero)

print('°' * 20 + 'Jogo da adivinhação' + '°' * 20)
print('O computador pensou em um numero de 0 a 10\ntente adivinhar o numero\n')

chute = int(input('Digite um numero: '))

tentativas = 1
while numero != chute:
    tentativas += 1
    chute = int(input('Digite um numero: '))

print('\n\nParabens, você acertou o numero de fato era \'{}\'\nVocê precisou de {} tentativas'.format(numero, tentativas))