'''
Faça um programa que leia o sexo de uma pessoa, mas só aceite os valores 'M' ou 'F'.
Caso esteja errado peça a digitação novamente até ter o valor correto
'''

# while True:
#     sexo = str(input('Digite seu sexo F/M: ').upper())
#
#     if sexo != 'M':
#         if sexo != 'F':
#             print('Digite Apenas M ou F')
#             continue


# Meu problema foi entender errado o enunciado, pensei que ele iria querer ler infinitos valors M e F

'''
Metodo do guanabara
'''

sexo = str(input('Digite seu sexo F/M: ')).strip().upper()

while sexo not in 'MF':
    sexo = str(input('Digite seu sexo F/M: ')).strip().upper()

print('Sexo {} registrado com sucesso'.format(sexo))

