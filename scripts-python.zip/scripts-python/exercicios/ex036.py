'''
# Escreva um progrma para aprovar o emprestimo bancário de uma casa. O progama vai perguntar o valor da casa,
o salário do comprador e em quantos anos ele vai pagar.

Calcule o valor da prestação mensal sabendo que ela não pode execer 30% do salário ou então o empresestimo sera negado
'''

vcasa = float(input('Digite o valor da casa que quer comprar: ')) # pergunta o valor da casa
salario = float(input('Digite o total do seu salário: ')) # pergunta o salário
anos = int(input('Digite em quantos anos você vai pagar: ')) # pergunta em quanto tempo (anos) a pessoa vai pagar
minimo = (salario * 30) / 100
pmensal = vcasa / (anos * 12)
#print(pmensal)

if pmensal > minimo:
    print('Emprestimo negado')
else:
    print('Emprestimo aprovado')
    print('Valor mensal a ser pago {:.2f}'.format(pmensal))

'''
Confesso que tive problema com a matematica na questao da parcela mensal e o minimo
'''
