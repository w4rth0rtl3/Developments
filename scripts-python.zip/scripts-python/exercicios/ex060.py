'''
Faça um programa que leia um número qualquer e mostre o seu fatorial. Exemplo:

5! = 5 x 4 x 3 x 2 x 1 = 120
'''

numero = int(input('Digite um numero para ver seu fatorial: ')) + 1 # Coleto o numero e sommo mais 1 para futuramente ele ser maior que 0 ou seja == 1
mult = 1 # crio uma variavel para multiplicar e coloco o numero 1 que nesse caso é o numero neutro da opereção
outp= '' #var iavel de saida (até o momento está vazia)

print('--' * 5, 'Fatorial', 5 * '--')# mostra algo bonitinho para o usuário final

print('{}! = '.format(numero -1), end='') # Mostra o numero mas o sinal de fatorial, atente-se que tirei -1 para ficar o nummero 'certo'

while numero != 1:
    numero -= 1
    mult *= numero # multiplica o numero pelo numero anterior
    #print(' {} x'.format(numero), end='') // isso aqui foi oq eu tentei fazer a principio
    outp += ("{} x ".format(numero)) # Joga na var output o "numero x" a cada loop

print(outp[:-2] + '=', mult) #nesse momento o output é tratado para que possa trocar o ultimo x  por um igual e mostra no final o resultado das operações


'''
OBSERVAÇÔES:

Por que utilizar uma variavel para o output ? 
R: caso usase um print não seria possivel tratar a saida sem um if
então no final sairia algo assim: 
    5! = 5 x 4 x 3 x 2 x 1 x = 120
na ultima linha eu removo 2 caracteres da var outp e com isso 
eu removo o 'x' e em seguida adiciono o '=' e mostro a multiplicação de todos os numeros que passaram pelo loop


Achei importante falar desse caso. ;]

'''



'''
Guanabara resolveu o problema do X e o = nesse exercicio usando um IF
porém eu não quis usar a praga de um IF 
'''