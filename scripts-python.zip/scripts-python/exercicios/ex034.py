'''
Escreva um programa que pergunte o salário de um funcionário e calcule o valor do seu aumento.
Para salários superiores a R$ 1.250,00, calcule um aumento de 10%.
Para inferiores ou iguais, o aumento é de 15%.
'''

salario = float(input('Digite o seu salario: R$'))
aumento = 0.00
if salario > 1250.00:
    print('Você tera um aumento de 10%')
    print('Novo salario: {}'.format(salario + (salario * 10 / 100)))

else:
    print('Você tera um aumento de 15%')
    print('Novo salario: {}'.format(salario + (salario * 15 / 100)))

'''

1250.00 100
x       10

'''