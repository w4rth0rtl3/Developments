'''
A confederação nacional de natação precisa de um programa que leia o ano de nascimento de um atleta
precisa de um programa que leia o ano de nascimento de um atleta e mostre a sua categoria

- até 9 anos: MIRIM
- Até 14 anos: INFANTIL
- Até 19 anos: JUNIOR
- Até 20 anos: SENIOR
- ACIMA de 20 anos: MASTER
'''

from datetime import date

nasc = int(input('Digite o ano do seu nascimento: '))
hoje = date.today().year
idade = hoje - nasc
#print(hoje)

if idade <= 9:
    print('Classificação:\nMirim')


elif idade <= 14:
    print('Classificação:\nInfantil')

elif idade <= 19:
    print('Classificação:\nJunior')

elif idade <= 20:
    print('Classificação:\nSenior')
else:
    print('Classificação:\nMaster')