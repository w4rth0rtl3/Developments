'''
Crie um programa que faça o computador jogar pedra, papel ou tesoura com você
'''

from random import randint
pcchoice = randint(1, 3)

#print(pcchoice)

print('-' * 50)
print(' ' * 20, 'Jokenpo')

uchoice = int(input('''

(1) rock
(2) Paper
(3) Scissor

> '''))

print('-' * 50)


print('Pc selected {}'.format(pcchoice))
if uchoice == 1:
    if pcchoice == 2:
        print('PC Wins')
    elif pcchoice == 3:
        print('You Wins')
    else:
        print('A tie')

elif uchoice == 2:
    if pcchoice == 3:
        print('PC Wins')
    elif pcchoice == 1:
        print('You Wins')
    else:
        print('A tie')

elif uchoice == 3:
    if pcchoice == 1:
        print('PC wins')
    elif pcchoice == 2:
        print('You wins')
    else:
        print('A tie')

else:
    print('Type just 1, 2 or 3')