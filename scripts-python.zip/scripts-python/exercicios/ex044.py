'''
Elabore um programa que calcule o valor a ser pago de um produto,
considerando o seu preço normal, e condição de pagamento:

- À vista no dinheiro/cheque: 10% de desconto
- À vista no cartão: 5% de desconto
- Em até 2x no cartão: preço normal
- 3x ou mais no cartão: 20% de juros
'''

valor = float(input('Digite o valor do produto: R$ '))
# Metodo de pagamento
mpagamento = str(input('''

======Metodos de pagamento=======
(1) À vista no dinheiro ou cheque
(2) Á vista no cartão
(3) Em até 2x no cartão
(4) 3x ou mais no cartão

Digite o número do metodo:
> '''))

if mpagamento == '1':
    print('Valor total a pagar {:.2f}'.format(valor - (valor * 10 / 100)))
    exit()

elif mpagamento == '2':
    print('Valor total a pagar {:.2f}'.format(valor - (valor * 5 / 100)))
    exit()

elif mpagamento == '3':
    print('Valor total a pagar {:.2f}'.format(valor))
    print('Valor por parcela {:.2f}R$'.format(valor / 2))
    exit()

elif mpagamento == '4':
    parcelas = int(input('Digite o total de parcelas: '))
    total = valor + (valor * 5 / 100)
    print('Valor total a pagar {:.2f}R$'.format(total))
    print('Valor por parcelas {:.2f}R$'.format(total / parcelas))
    exit()

else:
    print('Não entendi\nDigite apenas 1, 2, 3 ou 4')
    exit()
