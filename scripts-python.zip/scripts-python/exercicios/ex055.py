'''
Faça um programa que leia o peso de cinco pessoas. No
final mostre qual foi o maior e o menor peso lidos.
'''

maior = 0.00
menor = 0.00

for i in range (1, 5 + 1):
    peso = float(input('Digite o peso da {}° pessoa: '.format(i)))

    if i == 1:
        maior = peso
        menor = peso

    else:
        if peso < menor:
            menor = peso

        elif peso > maior:
            maior = peso


print('Maior peso é {}\nMenor peso é {}'.format(maior, menor))