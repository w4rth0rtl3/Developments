"""
Crie um codigo que receba dois numeros e mostre para o usuária a soma deles
"""

numero1 = int(input('Digite o valor '))
numero2 = int(input('Digite outro valor '))

soma = numero1 + numero2

print('A soma é:', soma)
# no exercicio 002 há outras formas de realizar esse print
print('A soma entre {} e {} é igual a: {}'.format(numero1, numero2, soma))
print(f'A soma entre {numero1} e {numero2} é igual a: {soma}')