'''
Faça um origrama que mostre na tela uma contagem regressiva para o estouro de fogos de artificio, indo de 10 até 0
com a pausa de 1 segundo entre eles
'''

from time import sleep

print('Contagem regresiva !')

for c in range(10, 0, -1):
    print(c, "\n")
    sleep(1)
print('Kabooom')