'''
Crie um programa que leia um número do usuário e mostre na tela a sua porção inteira
'''

from math import trunc


numero = float(input('Digite um numero: '))
print('O valor digitado foi {} e a sua porção inteira é {}'.format(numero, trunc(numero)))
print('blabalbal {}'.format(int(numero)))


'''
numero = float(input('Digite um numero: ' ))
print('blabalbal {}'.format(int(numero)))

'''