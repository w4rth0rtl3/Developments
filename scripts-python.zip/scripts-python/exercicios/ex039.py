'''
Escreva um programa que leia o ano de nascimento de um jovem e infomre de acordo com sua idade
- se ele ainda vai se alistar ao serviço militar
- se é hora de se alistar
- se já passou o tempo de se alistar

O programa também deve mostrar o tempo que falta ou que passou do prazo
'''


# limite = 30 de junho

#from datetime import date
import datetime

anodnasc = int(input('Digite o ano do seu nascimento: '))
hoje = datetime.date.today()
limite = datetime.date(2021, 6, 30)

#print(hoje)
#print(limite)

idade = hoje.year - anodnasc

if idade > 18:
    print('Ja passou a hora de se alistar\n')

elif idade == 18:
    print('Já ta no hora de se alistar\n')

else:
    print('Ainda não é hora de se alistar\n')
    if hoje < limite:
        print('Faltam {}'.format(limite - hoje))