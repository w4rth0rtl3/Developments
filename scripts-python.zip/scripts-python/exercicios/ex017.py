'''
Faça um programa que leia o comprimetno do cateto oposto e do cateto adjacente de um triangulo
retangulo, e calcule e mostre o comprimento da hipotenusa.
'''

cop = float(input('Digite o comprimento do cateto oposto: '))
cad = float(input('Digite o comprimento do cateto adjacente: '))
hipo = (((cad ** 2) + (cop ** 2)) ** (1/2))
print('A hipotenusa é: {:.2f}'.format(hipo))



'''
import math

cop = float(input('Digite o comprimento do cateto oposto: '))
cad = float(input('Digite o comprimento do cateto adjacente: '))
hipo = math.hypot(cop, cad)
print(f'{hipo:.2f}')
print('A hipotenusa é: {:.2f}'.format(hipo))

'''