'''
faça um programa que leia o salario de um funcionario e mostre seu novo salario com
15% de aumento
'''

salario = float(input('Digite o salario R$'))
# salario = salario + (salario * 15 / 100)
# print(salario)

aumento = (salario * 15) / 100
salario = salario + aumento

print('Seu novo salario é {}R$ pois agora você teve 15% de aumento'.format(salario))


'''
É possivel fazer com apenas 2 variaveis


salario = float(input('Digite o salario R$'))
salario = salario + (salario * 15 / 100)
print(salario)

'''