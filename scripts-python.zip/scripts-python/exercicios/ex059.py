'''
Crie um programa que leia dois valores e mostre um menu como o:

[1] soma
[2] multiplicar
[3] maior
[4] novos numeros
[5] sair

Seu programa deverá realizar a opreação solicitada em cada caso.
'''

from time import sleep

print('=-' * 20 + 'Sistema' + '=-' * 20)

valor1 = int(input('Digite o 1° valor:' ))
valor2 = int(input('Digite o 2° valor:' ))

menu ='''
[1] soma
[2] multiplicar
[3] maior
[4] novos numeros
[5] sair
'''

print(menu)
entrada = int(input('Digite a opção: '))

while entrada != 5:

    if entrada == 1:
        print('Soma = ', valor1 + valor2)

    elif entrada == 2:
        print('multiplicação = ', valor1 * valor2)

    elif entrada == 3:
        print('Analisando qual é o maior')
        sleep(2)

        if valor1 > valor2:
            print('O valor {} é maior que {}'.format(valor1, valor2))

        elif valor2 > valor1:
            print('O valor {} é maior que {}'.format(valor2, valor1))

        else:
            print('Os numeros {} e {} são iguais'.format(valor1, valor2))

    elif entrada == 4:
        print('Requisitando novos numeros...')
        sleep(1)

        valor1 = int(input('\nDigite o 1° valor:'))
        valor2 = int(input('Digite o 2° valor:'))
        print(menu)

    elif entrada > 5 or entrada <= 0:
        print('Digite apenas opções entre 1 - 5')

    entrada = int(input('Digite a opção: '))



print('=-' * 40)
print('Obrigado por utilizar o nosso sistema :)')

'''
Gostei de fazer esse script dá uma vontade de desenvolver uns exploits kkkk
não exploits em si, mas programas no geral relacionados a PoC para ethical Hacking
inclusive irei fazer um artigo a respeito disso logo logo.
'''